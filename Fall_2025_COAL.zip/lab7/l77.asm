[org 0x0100] 
              jmp  start 

clrscr:       push es 
              push ax 
              push di   
              mov  ax, 0xb800 
              mov  es, ax             ; point es to video base 
              mov  di, 0              ; point di to top left column 
 
nextloc:      mov  word [es:di], 0x0720 ; clear next char on screen 
              add  di, 2              ; move to next screen location 
              cmp  di, 4000           ; has the whole screen cleared 
              jne  nextloc            ; if no clear next position 
 
              pop  di 
              pop  ax 
              pop  es 
              ret 

printstr:     push bp 
              mov  bp, sp 
              push es 
              push ax 
              push di 

              mov  ax, 0xb800 
              mov  es, ax             ; point es to video base 
              mov  al, 80             ; load al with columns per row 
              mul byte [bp+6]       ; multiply with y position 
              add  ax, [bp+8]        ; add x position 
              shl  ax, 1              ; turn into byte offset 
              mov  di,0         ; point di to required location 
	    
  

nextchar: 
              mov word[es:di], 0x075F        ; show this char on screen 
              add  di, 2              ; move to next screen location
              cmp di,ax
              jne nextchar           ; repeat the operation cx times 
 
dotchar:             
              mov word[es:di], 0x072E        ; show this char on screen 
              add  di, 2              ; move to next screen location
              cmp di, 4000
              jne dotchar

              pop  di 
              pop  ax 
              pop  es 
              pop  bp 
              ret  6
 
start:        call clrscr             ; call the clrscr subroutine 
 
              mov  ax, 80
              push ax                 ; push x position  
              mov  ax, 13
              push ax                 ; push y position  
              mov  ax, 7            ; blue on black attribute 
              push ax                 ; push attribute  
        
              call printstr           ; call the printstr subroutine 
 
              mov  ax, 0x4c00         ; terminate program 
              int  0x21