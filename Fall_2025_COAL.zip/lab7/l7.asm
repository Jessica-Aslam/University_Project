[org 0x0100] 
              jmp  start 

clrscr:       push es 
              push ax 
              push di   
              mov  ax, 0xb800 
              mov  es, ax             ; point es to video base 
              mov  di, 0              ; point di to top left column 
 
nextloc:      mov  word [es:di], 0x0720 ; clear next char on screen 
              add  di, 2              ; move to next screen location 
              cmp  di, 4000           ; has the whole screen cleared 
              jne  nextloc            ; if no clear next position 
 
              pop  di 
              pop  ax 
              pop  es 
              ret 

printstr:   
              push es 
              push ax 
              push di   
 	      mov  ax, 0xb800 
              mov  es, ax             ; point es to video base 
              mov  di, 0              ; point di to top left column 
 
nextlocation:      mov  word [es:di], 0x0241 ; clear next char on screen 
             	   add  di, 2              ; move to next screen location 
                   cmp  di, 4000           ; has the whole screen cleared 
                   jne  nextlocation           ; if no clear next position 
 
              pop  di 
              pop  ax 
              pop  es 
              ret 
   
start:        call clrscr             ; call the clrscr subroutine 
 
              call printstr           ; call the printstr subroutine 
 
              mov  ax, 0x4c00         ; terminate program 
              int  0x21 