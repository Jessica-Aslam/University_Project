[org 0x0100] 
jmp  start 
 
top:  dw 1
bottom: dw 20
right: dw 30
left: dw 10
attribute : dw 0x07


clrscr:       push es 
              push ax 
              push cx 
              push di 
              mov  ax, 0xb800 
              mov  es, ax             ; point es to video base 
              xor  di, di             ; point di to top left column 
              mov  ax, 0x0720        ; space char in normal attribute 
              mov  cx, 2000           ; number of screen locations 
              cld                     ; auto increment mode 
              rep  stosw              ; clear the whole screen 
              pop  di
              pop  cx 
              pop  ax 
              pop  es 
              ret 
 

printstr:     push bp 
              mov  bp, sp
              push ax 
              push es
              push cx
              push si 
              push di 
 
              mov  ax, 0xb800 
              mov  es, ax             ; point es to video base 

top_left:     mov  al, 80            ; load al with columns per row 
              mul  byte[bp+12]       ; y pos top
              add  ax, [bp+6]        ; x position left
              shl  ax, 1              ; turn into byte offset 
              mov  di,ax              ; 20 value
  	      mov  ah, [bp+14]        ; attribute  



              mov  al, 35             ; #
              mov  cx,[bp+4]       ; right-left value  
l1:
	mov word[es:di],ax  
	add di,2
loop    l1
                       ; print char/attribute pair 
              
top_right:      mov al,80
	        mul byte[bp+12]
	        add ax,[bp+8]
		shl ax,1
		mov di,ax
		mov ah,[bp+14]
		mov al,35

top_bottom_right: 	
		mov cx,[bp+10]			;top to bottom
		sub cx,[bp+12]

l2:
	mov word[es:di],ax  
	add di,160
loop    l2

top_bottom_left: mov  al, 80            ; load al with columns per row 
              mul  byte[bp+12]       ; y pos top
              add  ax, [bp+6]        ; x position left
              shl  ax, 1              ; turn into byte offset 
              mov  di,ax              ; 20 value
  	      mov  ah, [bp+14]        ; attribute  
              mov  al, 35 
	      mov cx,[bp+10]			;top to bottom
	      sub cx,[bp+12]
l3:
	mov word[es:di],ax  
	add di,160
loop    l3

bottom_left:
                mov al,80
                mul byte[bp+10]
                add ax,[bp+6]
                shl ax,1
                mov di,ax
                mov ah,[bp+14]
                mov al,35
                mov cx,[bp+4]
                inc cx.
               
l4:
	mov word[es:di],ax  
	add di,2
loop    l4
              pop  di 
              pop  si 
              pop  cx 
              pop  es
              pop  ax 
              pop  bp 
              ret  12
 
start:        call clrscr             ; call the clrscr subroutine 
         
              mov ax,[attribute]
              push ax
              mov ax,[top]
              push ax
              mov ax,[bottom]
              push ax
 	      mov ax,[right]
              push ax
	      mov ax,[left]
              push ax
              mov bx,[right]
              sub bx,[left]  
	      push bx
              call printstr           ; call the printstr subroutine 
 
              mov  ax, 0x4c00         ; terminate program 
              int  0x21

