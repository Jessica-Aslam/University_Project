org 100h

start:
    call cls
    call draw_all

main:
    ; Check for key
    mov ah, 1
    int 16h
    jz near do_stars  ; No key, do stars
    
    ; Key pressed
    mov ah, 0
    int 16h
    
    cmp ah, 48h
    je near key_up
    cmp ah, 50h
    je near key_down
    cmp al, 0Dh
    je near key_enter
    cmp al, 1Bh
    je near key_exit
    cmp al, 's'
    je near key_sound_toggle
    cmp al, 'S'
    je near key_sound_toggle
    jmp near main

do_stars:
    call move_stars
    call draw_stars
    call delay_slow  ; Slow delay for menu stars
    jmp near main

key_up:
    cmp byte [select], 0
    jne .not_top
    mov byte [select], 3
    jmp .redraw
.not_top:
    dec byte [select]
.redraw:
    call draw_menu
    jmp near main

key_down:
    cmp byte [select], 3
    jne .not_bottom
    mov byte [select], 0
    jmp .redraw2
.not_bottom:
    inc byte [select]
.redraw2:
    call draw_menu
    jmp near main

key_enter:
    mov al, [select]
    cmp al, 0
    je near do_start
    cmp al, 1
    je near do_help
    cmp al, 2
    je near do_settings
    jmp near key_exit

key_sound_toggle:
    ; Toggle sound from anywhere
    xor byte [sound_enabled], 1
    call play_menu_beep  ; Play beep if sound is enabled
    call draw_menu
    jmp near main

do_start:
    call play_menu_beep
    call tutorial_game
    call cls
    call draw_all
    jmp near main

do_help:
    call play_menu_beep
    call show_instructions
    call cls
    call draw_all
    jmp near main

do_settings:
    call play_menu_beep
    call show_settings
    call cls
    call draw_all
    jmp near main

key_exit:
    call play_exit_beep
    mov ax, 4C00h
    int 21h

; ========== TUTORIAL GAME ==========
tutorial_game:
    pusha
    call cls
    
    ; Draw tutorial frame
    call draw_tutorial_frame
    
    ; Initialize tutorial state
    mov byte [jelly_x], 40
    mov byte [jelly_y], 12
    mov word [tutorial_score], 0
    mov byte [tutorial_step], 0
    mov byte [stars_collected], 0
    mov byte [tutorial_timer], 0
    mov byte [obstacle_active], 0
    mov byte [powerup_active], 0
    mov byte [tutorial_progress], 0
    
    ; Initialize tutorial objects
    call init_tutorial_objects
    
    ; Display initial tutorial message
    call show_tutorial_message
    
.tutorial_loop:
    ; Draw everything
    call draw_tutorial_elements
    call draw_jelly
    call draw_tutorial_objects
    call draw_tutorial_hud
    
    ; Check for key press (non-blocking)
    mov ah, 1
    int 16h
    jnz .process_key  ; Jump if key available
    jmp .no_key       ; Jump forward to no_key
    
.process_key:
    ; Key was pressed, read it
    mov ah, 0
    int 16h
    
    ; Handle movement based on tutorial step
    cmp byte [tutorial_step], 1
    jl .step0
    je .step1
    cmp byte [tutorial_step], 2
    je .step2
    cmp byte [tutorial_step], 3
    je .step3
    jmp .check_exit

.step0:
    ; Any key to start step 1
    inc byte [tutorial_step]
    call show_tutorial_message
    jmp .tutorial_loop

.step1:
    ; Step 1: Learn movement
    cmp ah, 4Bh  ; Left arrow
    je .move_left
    cmp ah, 4Dh  ; Right arrow
    je .move_right
    cmp ah, 48h  ; Up arrow
    je .move_up
    cmp ah, 50h  ; Down arrow
    je .move_down
    jmp .check_exit

.step2:
    ; Step 2: Collect stars
    cmp ah, 4Bh  ; Left arrow
    je .move_left
    cmp ah, 4Dh  ; Right arrow
    je .move_right
    cmp ah, 48h  ; Up arrow
    je .move_up
    cmp ah, 50h  ; Down arrow
    je .move_down
    jmp .check_exit

.step3:
    ; Step 3: Avoid obstacles
    cmp ah, 4Bh  ; Left arrow
    je .move_left
    cmp ah, 4Dh  ; Right arrow
    je .move_right
    cmp ah, 48h  ; Up arrow
    je .move_up
    cmp ah, 50h  ; Down arrow
    je .move_down
    jmp .check_exit

.move_left:
    cmp byte [jelly_x], 2
    jle .after_move
    dec byte [jelly_x]
    call play_move_sound
    jmp .after_move

.move_right:
    cmp byte [jelly_x], 77
    jge .after_move
    inc byte [jelly_x]
    call play_move_sound
    jmp .after_move

.move_up:
    cmp byte [jelly_y], 2
    jle .after_move
    dec byte [jelly_y]
    call play_move_sound
    jmp .after_move

.move_down:
    cmp byte [jelly_y], 22
    jge .after_move
    inc byte [jelly_y]
    call play_move_sound
    jmp .after_move

.after_move:
    ; Check collisions
    call check_tutorial_collisions
    
    ; Check if tutorial step is complete
    call check_tutorial_progress
    
    jmp .tutorial_loop

.check_exit:
    cmp al, 1Bh  ; ESC
    je .exit_tutorial
    cmp al, 0Dh  ; Enter
    je .exit_tutorial
    jmp .tutorial_loop

.no_key:
    ; Animate obstacles if active
    cmp byte [tutorial_step], 3
    jl .skip_obstacle_anim
    call animate_obstacle
.skip_obstacle_anim:
    
    ; Slow down the tutorial
    call delay_slow
    jmp .tutorial_loop

.exit_tutorial:
    call cls
    popa
    ret

draw_tutorial_frame:
    ; Top border
    mov dh, 0
    mov dl, 0
    call set_cur
    mov si, tutorial_border_top
    mov bl, 09h  ; Blue
    call print_color
    
    ; Sides
    mov cx, 22
    mov dh, 1
.draw_sides:
    push cx
    mov dl, 0
    call set_cur
    mov si, tutorial_border_side
    mov bl, 09h
    call print_color
    
    mov dl, 79
    call set_cur
    mov si, tutorial_border_side
    mov bl, 09h
    call print_color
    
    inc dh
    pop cx
    loop .draw_sides
    
    ; Bottom border
    mov dh, 23
    mov dl, 0
    call set_cur
    mov si, tutorial_border_bottom
    mov bl, 09h
    call print_color
    
    ; Title
    mov dh, 1
    mov dl, 30
    call set_cur
    mov si, tutorial_title
    mov bl, 0Eh  ; Yellow
    call print_color
    
    ret

draw_tutorial_elements:
    ; Draw ground
    mov dh, 23
    mov dl, 1
    call set_cur
    mov cx, 78
    mov al, 0DBh  ; Block character
    mov bl, 02h   ; Green
.ground_loop:
    call print_color_char
    inc dl
    call set_cur
    loop .ground_loop
    
    ; Draw some platforms for tutorial
    ; Platform 1
    mov dh, 18
    mov dl, 20
    call set_cur
    mov cx, 10
    mov al, 0B0h  ; Shaded block
    mov bl, 08h   ; Gray
.platform1_loop:
    call print_color_char
    inc dl
    call set_cur
    loop .platform1_loop
    
    ; Platform 2
    mov dh, 15
    mov dl, 50
    call set_cur
    mov cx, 8
    mov al, 0B0h
    mov bl, 08h
.platform2_loop:
    call print_color_char
    inc dl
    call set_cur
    loop .platform2_loop
    
    ret

draw_jelly:
    ; Draw jelly character (smiley face)
    mov dh, [jelly_y]
    mov dl, [jelly_x]
    call set_cur
    mov al, 01h   ; Smiley face character
    mov bl, 0Dh   ; Pink/Magenta for jelly
    call print_color_char
    
    ; Draw jelly trail (optional)
    mov dh, [jelly_y]
    mov dl, [jelly_x]
    dec dl
    call set_cur
    mov al, 0F9h  ; Small dot
    mov bl, 0Fh   ; White
    call print_color_char
    
    ret

init_tutorial_objects:
    ; Initialize stars for collection
    mov byte [star1_x], 30
    mov byte [star1_y], 10
    mov byte [star1_active], 1
    
    mov byte [star2_x], 60
    mov byte [star2_y], 14
    mov byte [star2_active], 1
    
    mov byte [star3_x], 45
    mov byte [star3_y], 8
    mov byte [star3_active], 1
    
    ; Initialize obstacle
    mov byte [obstacle_x], 70
    mov byte [obstacle_y], 12
    mov byte [obstacle_active], 0
    mov byte [obstacle_dir], 0  ; 0=down, 1=up
    
    ; Initialize power-up
    mov byte [powerup_x], 10
    mov byte [powerup_y], 18
    mov byte [powerup_active], 0
    mov byte [powerup_type], 0  ; 0=speed, 1=shield
    
    ret

draw_tutorial_objects:
    ; Draw stars if active
    cmp byte [star1_active], 1
    jne .check_star2
    mov dh, [star1_y]
    mov dl, [star1_x]
    call set_cur
    mov al, '*'   ; Star character
    mov bl, 0Eh   ; Yellow
    call print_color_char
    
.check_star2:
    cmp byte [star2_active], 1
    jne .check_star3
    mov dh, [star2_y]
    mov dl, [star2_x]
    call set_cur
    mov al, '*'
    mov bl, 0Eh
    call print_color_char
    
.check_star3:
    cmp byte [star3_active], 1
    jne .draw_obstacle
    mov dh, [star3_y]
    mov dl, [star3_x]
    call set_cur
    mov al, '*'
    mov bl, 0Eh
    call print_color_char

.draw_obstacle:
    cmp byte [obstacle_active], 1
    jne .draw_powerup
    mov dh, [obstacle_y]
    mov dl, [obstacle_x]
    call set_cur
    mov al, 178   ; Dark shaded block
    mov bl, 0Ch   ; Red
    call print_color_char

.draw_powerup:
    cmp byte [powerup_active], 1
    jne .done_objects
    mov dh, [powerup_y]
    mov dl, [powerup_x]
    call set_cur
    mov al, 0Fh   ; Diamond character
    cmp byte [powerup_type], 0
    je .speed_powerup
    mov bl, 0Ah   ; Green for shield
    jmp .draw_powerup_char
.speed_powerup:
    mov bl, 09h   ; Blue for speed
.draw_powerup_char:
    call print_color_char

.done_objects:
    ret

animate_obstacle:
    ; Only animate in step 3
    cmp byte [tutorial_step], 3
    jne .done_animation
    
    ; Move obstacle up and down
    cmp byte [obstacle_dir], 0
    je .move_down
    ; Move up
    dec byte [obstacle_y]
    cmp byte [obstacle_y], 10
    jg .done_move
    mov byte [obstacle_dir], 0
    jmp .done_move
.move_down:
    inc byte [obstacle_y]
    cmp byte [obstacle_y], 20
    jl .done_move
    mov byte [obstacle_dir], 1
.done_move:
    
    ; Activate power-up randomly
    inc byte [tutorial_timer]
    cmp byte [tutorial_timer], 50
    jl .done_animation
    mov byte [tutorial_timer], 0
    mov byte [powerup_active], 1
    mov byte [powerup_x], 5
    mov byte [powerup_y], 15
    
.done_animation:
    ret

check_tutorial_collisions:
    ; Check star1 collision
    cmp byte [star1_active], 1
    jne .check_star2
    mov al, [jelly_x]
    cmp al, [star1_x]
    jne .check_star2
    mov al, [jelly_y]
    cmp al, [star1_y]
    jne .check_star2
    ; Collision with star1!
    mov byte [star1_active], 0
    call play_collect_sound
    inc byte [stars_collected]
    add word [tutorial_score], 10
    
.check_star2:
    cmp byte [star2_active], 1
    jne .check_star3
    mov al, [jelly_x]
    cmp al, [star2_x]
    jne .check_star3
    mov al, [jelly_y]
    cmp al, [star2_y]
    jne .check_star3
    ; Collision with star2!
    mov byte [star2_active], 0
    call play_collect_sound
    inc byte [stars_collected]
    add word [tutorial_score], 10
    
.check_star3:
    cmp byte [star3_active], 1
    jne .check_obstacle
    mov al, [jelly_x]
    cmp al, [star3_x]
    jne .check_obstacle
    mov al, [jelly_y]
    cmp al, [star3_y]
    jne .check_obstacle
    ; Collision with star3!
    mov byte [star3_active], 0
    call play_collect_sound
    inc byte [stars_collected]
    add word [tutorial_score], 10

.check_obstacle:
    ; Check obstacle collision (only in step 3)
    cmp byte [tutorial_step], 3
    jl .check_powerup
    cmp byte [obstacle_active], 1
    jne .check_powerup
    
    mov al, [jelly_x]
    cmp al, [obstacle_x]
    jne .check_powerup
    mov al, [jelly_y]
    cmp al, [obstacle_y]
    jne .check_powerup
    
    ; Hit obstacle!
    call play_hit_sound
    ; Move jelly back
    mov byte [jelly_x], 40
    mov byte [jelly_y], 12

.check_powerup:
    ; Check power-up collision
    cmp byte [powerup_active], 1
    jne .collision_done
    
    mov al, [jelly_x]
    cmp al, [powerup_x]
    jne .collision_done
    mov al, [jelly_y]
    cmp al, [powerup_y]
    jne .collision_done
    
    ; Collected power-up!
    call play_powerup_sound
    mov byte [powerup_active], 0
    add word [tutorial_score], 25
    
.collision_done:
    ret

check_tutorial_progress:
    ; Step 1: Movement tutorial (complete after moving a bit)
    cmp byte [tutorial_step], 1
    jne .check_step2
    
    inc byte [tutorial_progress]
    cmp byte [tutorial_progress], 10
    jl .progress_done
    
    ; Complete step 1
    inc byte [tutorial_step]
    mov byte [tutorial_progress], 0
    call show_tutorial_message
    ; Activate stars for step 2
    mov byte [star1_active], 1
    mov byte [star2_active], 1
    mov byte [star3_active], 1
    jmp .progress_done

.check_step2:
    cmp byte [tutorial_step], 2
    jne .check_step3
    
    ; Complete when all stars collected
    cmp byte [stars_collected], 3
    jl .progress_done
    
    ; Complete step 2
    inc byte [tutorial_step]
    mov byte [tutorial_progress], 0
    call show_tutorial_message
    ; Activate obstacle for step 3
    mov byte [obstacle_active], 1
    jmp .progress_done

.check_step3:
    cmp byte [tutorial_step], 3
    jne .progress_done
    
    ; Complete after surviving for a while
    inc byte [tutorial_progress]
    cmp byte [tutorial_progress], 30
    jl .progress_done
    
    ; Complete step 3 (end tutorial)
    inc byte [tutorial_step]
    call show_tutorial_message

.progress_done:
    ret

show_tutorial_message:
    ; Clear message area
    mov dh, 20
    mov dl, 10
    call set_cur
    mov cx, 60
.clear_msg:
    mov al, ' '
    call print_color_char
    inc dl
    call set_cur
    loop .clear_msg
    
    ; Display message based on tutorial step
    mov dh, 20
    mov dl, 10
    call set_cur
    
    cmp byte [tutorial_step], 0
    je .step0_msg
    cmp byte [tutorial_step], 1
    je .step1_msg
    cmp byte [tutorial_step], 2
    je .step2_msg
    cmp byte [tutorial_step], 3
    je .step3_msg
    cmp byte [tutorial_step], 4
    je .step4_msg
    
    ; Default message
    mov si, tutorial_complete_msg
    jmp .display_msg

.step0_msg:
    mov si, tutorial_welcome_msg
    jmp .display_msg
.step1_msg:
    mov si, tutorial_move_msg
    jmp .display_msg
.step2_msg:
    mov si, tutorial_collect_msg
    jmp .display_msg
.step3_msg:
    mov si, tutorial_avoid_msg
    jmp .display_msg
.step4_msg:
    mov si, tutorial_complete_msg

.display_msg:
    mov bl, 0Bh  ; Cyan
    call print_color
    ret

draw_tutorial_hud:
    ; Draw score
    mov dh, 2
    mov dl, 2
    call set_cur
    mov si, tutorial_score_text
    mov bl, 0Fh  ; White
    call print_color
    
    mov dh, 2
    mov dl, 10
    call set_cur
    mov ax, [tutorial_score]
    call print_number
    
    ; Draw step indicator
    mov dh, 2
    mov dl, 60
    call set_cur
    mov si, tutorial_step_text
    mov bl, 0Fh
    call print_color
    
    mov dh, 2
    mov dl, 66
    call set_cur
    mov al, [tutorial_step]
    add al, '1'
    call print_char
    
    ; Draw controls help
    mov dh, 22
    mov dl, 2
    call set_cur
    mov si, tutorial_controls
    mov bl, 0Ah  ; Green
    call print_color
    
    ret

print_number:
    ; Print a number (0-999) at current cursor position
    pusha
    mov cx, 0
    mov bx, 10
    
    cmp ax, 0
    jne .convert_loop
    mov al, '0'
    call print_char
    jmp .print_done
    
.convert_loop:
    xor dx, dx
    div bx
    push dx
    inc cx
    test ax, ax
    jnz .convert_loop
    
.print_loop:
    pop ax
    add al, '0'
    call print_char
    loop .print_loop
    
.print_done:
    popa
    ret

print_char:
    push ax
    push bx
    mov ah, 0Eh
    mov bh, 0
    int 10h
    pop bx
    pop ax
    ret

play_move_sound:
    cmp byte [sound_enabled], 0
    je .no_sound
    mov ax, 1200
    call quick_beep
.no_sound:
    ret

play_collect_sound:
    cmp byte [sound_enabled], 0
    je .no_sound
    mov ax, 1500
    call quick_beep
    call quick_beep
.no_sound:
    ret

play_hit_sound:
    cmp byte [sound_enabled], 0
    je .no_sound
    mov ax, 300
    call quick_beep
.no_sound:
    ret

play_powerup_sound:
    cmp byte [sound_enabled], 0
    je .no_sound
    mov ax, 2000
    call quick_beep
    mov ax, 1800
    call quick_beep
.no_sound:
    ret

; ========== INSTRUCTIONS SCREEN WITH SCROLLING ==========
show_instructions:
    pusha
    call cls
    
    ; Draw instructions frame
    call draw_instructions_frame
    
    ; Set initial scroll position
    mov word [scroll_pos], 0
    
.instructions_loop:
    ; Display instructions with current scroll position
    call display_instructions
    
    ; Wait for key
    mov ah, 0
    int 16h
    
    cmp ah, 48h        ; Up arrow
    je .scroll_up
    cmp ah, 50h        ; Down arrow
    je .scroll_down
    cmp al, 1Bh        ; ESC
    je .exit_instructions
    cmp al, 0Dh        ; Enter
    je .exit_instructions
    jmp .instructions_loop

.scroll_up:
    cmp word [scroll_pos], 0
    je .instructions_loop
    dec word [scroll_pos]
    call play_scroll_beep
    jmp .instructions_loop

.scroll_down:
    cmp word [scroll_pos], 40  ; Max scroll position
    jae .instructions_loop
    inc word [scroll_pos]
    call play_scroll_beep
    jmp .instructions_loop

.exit_instructions:
    popa
    ret

draw_instructions_frame:
    ; Top border
    mov dh, 0
    mov dl, 0
    call set_cur
    mov si, border_top
    mov bl, 0Bh
    call print_color
    
    ; Sides and content
    mov cx, 22
    mov dh, 1
.draw_sides:
    push cx
    mov dl, 0
    call set_cur
    mov si, border_side
    mov bl, 0Bh
    call print_color
    
    mov dl, 79
    call set_cur
    mov si, border_side
    mov bl, 0Bh
    call print_color
    
    inc dh
    pop cx
    loop .draw_sides
    
    ; Bottom border
    mov dh, 23
    mov dl, 0
    call set_cur
    mov si, border_bottom
    mov bl, 0Bh
    call print_color
    
    ; Title
    mov dh, 1
    mov dl, 30
    call set_cur
    mov si, instr_title
    mov bl, 0Eh
    call print_color
    
    ; Controls
    mov dh, 22
    mov dl, 25
    call set_cur
    mov si, instr_controls
    mov bl, 0Ah
    call print_color
    
    ret

display_instructions:
    pusha
    
    ; Clear content area (rows 3-21)
    mov cx, 18
    mov dh, 3
.clear_area:
    push cx
    mov dl, 2
    call set_cur
    mov cx, 76
    mov bl, 0Fh
.clear_line:
    push dx
    mov al, ' '
    call print_color_char
    pop dx
    inc dl
    call set_cur
    loop .clear_line
    pop cx
    inc dh
    loop .clear_area
    
    ; Display instructions based on scroll position
    mov dh, 3
    mov dl, 5
    mov si, instructions_text
    
    ; Skip lines based on scroll position
    mov cx, [scroll_pos]
    cmp cx, 0
    je .display_lines
    
.skip_lines:
    call skip_to_next_line
    loop .skip_lines

.display_lines:
    mov cx, 18  ; Lines to display
.display_loop:
    push cx
    push si
    
    ; Check if we reached end of text
    cmp byte [si], 0
    je .end_of_text
    
    ; Set cursor
    call set_cur
    
    ; Print line
    mov bl, 0Fh
    call print_color_line
    
    ; Get next line position
    pop si
    call find_next_line
    mov si, ax
    
    pop cx
    
    inc dh
    cmp dh, 21  ; Bottom of display area
    jg .done
    loop .display_loop
    jmp .done

.end_of_text:
    pop si
    pop cx

.done:
    ; Show scroll indicator
    mov dh, 22
    mov dl, 75
    call set_cur
    mov si, scroll_indicator
    mov bl, 0Eh
    call print_color
    
    popa
    ret

print_color_line:
    pusha
.print_line_loop:
    lodsb
    cmp al, 0
    je .line_done
    cmp al, 13
    je .line_done
    cmp al, 10
    je .line_done
    call print_color_char
    inc dl
    call set_cur
    jmp .print_line_loop
.line_done:
    popa
    ret

skip_to_next_line:
    pusha
.skip_loop:
    lodsb
    cmp al, 0
    je .done
    cmp al, 13
    je .check_newline
    jmp .skip_loop
.check_newline:
    lodsb
    cmp al, 10
    je .done
    jmp .skip_loop
.done:
    mov [.temp_si], si
    popa
    mov si, [.temp_si]
    ret
.temp_si: dw 0

find_next_line:
    pusha
.find_loop:
    lodsb
    cmp al, 0
    je .found
    cmp al, 13
    je .check_next
    jmp .find_loop
.check_next:
    lodsb
    cmp al, 10
    je .found
    jmp .find_loop
.found:
    mov [.temp_si], si
    popa
    mov ax, [.temp_si]
    ret
.temp_si: dw 0

; ========== SETTINGS SCREEN ==========
show_settings:
    pusha
    call cls
    
    ; Draw settings frame
    call draw_settings_frame
    
    ; Display settings
    mov dh, 10
    mov dl, 30
    call set_cur
    mov si, settings_title
    mov bl, 0Eh
    call print_color
    
    ; Sound setting
    mov dh, 12
    mov dl, 30
    call set_cur
    mov si, txt_sound
    mov bl, 0Fh
    call print_color
    
    mov dh, 12
    mov dl, 45
    call set_cur
    cmp byte [sound_enabled], 0
    je .sound_off
    mov si, txt_on
    mov bl, 0Ah
    call print_color
    jmp .display_controls
    
.sound_off:
    mov si, txt_off
    mov bl, 0Ch
    call print_color

.display_controls:
    mov dh, 15
    mov dl, 25
    call set_cur
    mov si, settings_controls
    mov bl, 0Bh
    call print_color
    
    ; Wait for key
.wait_key:
    mov ah, 0
    int 16h
    
    cmp al, 's'
    je .toggle_sound
    cmp al, 'S'
    je .toggle_sound
    cmp al, 1Bh
    je .exit_settings
    cmp al, 0Dh
    je .exit_settings
    jmp .wait_key

.toggle_sound:
    xor byte [sound_enabled], 1
    call play_menu_beep
    ; Redraw settings screen instead of jumping back
    popa  ; Clean up stack
    call show_settings  ; Refresh screen
    ret   ; This will return to do_settings which will return to main

.exit_settings:
    popa
    ret

draw_settings_frame:
    ; Simple box around settings
    mov dh, 8
    mov dl, 25
    call set_cur
    mov si, settings_top
    mov bl, 0Dh
    call print_color
    
    mov cx, 7
    mov dh, 9
.draw_settings_sides:
    push cx
    mov dl, 25
    call set_cur
    mov si, settings_side
    mov bl, 0Dh
    call print_color
    
    mov dl, 55
    call set_cur
    mov si, settings_side
    mov bl, 0Dh
    call print_color
    
    inc dh
    pop cx
    loop .draw_settings_sides
    
    mov dh, 16
    mov dl, 25
    call set_cur
    mov si, settings_bottom
    mov bl, 0Dh
    call print_color
    ret

; ========== TWO STARS ANIMATION ==========
two_stars_animation:
    pusha
    call cls
    
    ; Display animation title
    mov dh, 5
    mov dl, 30
    call set_cur
    mov si, txt_anim_title
    mov bl, 0Eh
    call print_color
    
    mov dh, 7
    mov dl, 25
    call set_cur
    mov si, txt_anim_instructions
    mov bl, 0Ah
    call print_color
    
    ; Initialize positions
    mov word [left_pos], 0
    mov word [right_pos], 79
    
.anim_loop:
    ; Move in phase
.move_in:
    ; Clear previous stars using BIOS
    mov dh, 12  ; Center row
    mov dl, 0
    call set_cur
    mov cx, 80
    mov ah, 0Eh
.clear_row_in:
    mov al, ' '
    int 10h
    loop .clear_row_in
    
    ; Draw new stars
    mov dh, 12
    mov dl, [left_pos]
    call set_cur
    mov al, '*'
    mov bl, 0Eh  ; Yellow stars
    call print_color_char
    
    mov dh, 12
    mov dl, [right_pos]
    call set_cur
    mov al, '*'
    mov bl, 0Eh  ; Yellow stars
    call print_color_char
    
    ; Check for key press
    mov ah, 1
    int 16h
    jnz .exit_animation
    
    call delay_fast
    
    ; Update positions
    inc word [left_pos]
    dec word [right_pos]
    
    ; Check if stars met
    mov ax, [left_pos]
    cmp ax, [right_pos]
    jl .move_in  ; Continue moving in
    
    ; Move out phase
.move_out:
    ; Clear row
    mov dh, 12
    mov dl, 0
    call set_cur
    mov cx, 80
    mov ah, 0Eh
.clear_row_out:
    mov al, ' '
    int 10h
    loop .clear_row_out
    
    ; Draw stars
    mov dh, 12
    mov dl, [left_pos]
    call set_cur
    mov al, '*'
    mov bl, 0Eh  ; Yellow stars
    call print_color_char
    
    mov dh, 12
    mov dl, [right_pos]
    call set_cur
    mov al, '*'
    mov bl, 0Eh  ; Yellow stars
    call print_color_char
    
    ; Check for key press
    mov ah, 1
    int 16h
    jnz .exit_animation
    
    call delay_fast
    
    ; Update positions
    dec word [left_pos]
    inc word [right_pos]
    
    ; Check if back to start
    cmp word [left_pos], 0
    jg .move_out  ; Continue moving out
    
    jmp .anim_loop  ; Restart animation

.exit_animation:
    ; Clear any key in buffer
    mov ah, 0
    int 16h
    
    popa
    ret

; ========== SOUND FUNCTIONS ==========
play_menu_beep:
    cmp byte [sound_enabled], 0
    je .no_sound
    ; Short beep for menu
    mov ax, 1000  ; Frequency
    call quick_beep
.no_sound:
    ret

play_scroll_beep:
    cmp byte [sound_enabled], 0
    je .no_sound
    ; Quick beep for scrolling
    mov ax, 800   ; Frequency
    call quick_beep
.no_sound:
    ret

play_exit_beep:
    cmp byte [sound_enabled], 0
    je .no_sound
    ; Low beep for exit
    mov ax, 500   ; Low frequency
    call quick_beep
.no_sound:
    ret

quick_beep:
    pusha
    ; Set up PIT for sound
    mov dx, ax
    mov al, 0B6h
    out 43h, al
    mov ax, dx
    out 42h, al
    mov al, ah
    out 42h, al
    
    ; Turn on speaker
    in al, 61h
    or al, 3
    out 61h, al
    
    ; Short delay
    mov cx, 2000
.beep_delay:
    loop .beep_delay
    
    ; Turn off speaker
    in al, 61h
    and al, 0FCh
    out 61h, al
    popa
    ret

; ========== DELAY FUNCTIONS ==========
delay_slow:
    push cx
    push dx
    mov cx, 1
.d1:
    mov dx, 30000
.d2:
    dec dx
    jnz .d2
    loop .d1
    pop dx
    pop cx
    ret

delay_fast:
    push cx
    push dx
    mov cx, 2
.f1:
    mov dx, 10000
.f2:
    dec dx
    jnz .f2
    loop .f1
    pop dx
    pop cx
    ret

; ========== BASIC FUNCTIONS ==========
cls:
    mov ax, 3
    int 10h
    ret

set_cur:
    mov ah, 2
    mov bh, 0
    int 10h
    ret

print:
    push ax
    push bx
print_loop:
    lodsb
    cmp al, 0
    je print_done
    mov ah, 0Eh
    mov bh, 0
    int 10h
    jmp print_loop
print_done:
    pop bx
    pop ax
    ret

print_color:
    push ax
    push bx
    push cx
pc_loop:
    lodsb
    cmp al, 0
    je pc_done
    mov ah, 09h
    mov bh, 0
    mov cx, 1
    int 10h
    inc dl
    call set_cur
    jmp pc_loop
pc_done:
    pop cx
    pop bx
    pop ax
    ret

print_color_char:
    push ax
    push bx
    push cx
    mov ah, 09h
    mov bh, 0
    mov cx, 1
    int 10h
    pop cx
    pop bx
    pop ax
    ret

; ========== STAR FUNCTIONS ==========
move_stars:
    mov cx, 10
    mov si, stars
ms_loop:
    dec byte [si]
    cmp byte [si], 0
    jg ms_ok
    mov byte [si], 79
    ; Simple random Y
    mov ax, [random]
    add ax, 9248h
    mov [random], ax
    and al, 23
    add al, 1
    mov [si+1], al
ms_ok:
    add si, 2
    loop ms_loop
    ret

draw_stars:
    mov cx, 10
    mov si, stars
ds_loop:
    push cx
    push si
    
    ; Get star coordinates
    mov dl, [si]      ; X position
    mov dh, [si+1]    ; Y position
    
    ; Set cursor position
    call set_cur
    
    ; Get star index for color selection
    mov ax, si
    sub ax, stars     ; Calculate star index (0, 2, 4...)
    shr ax, 1         ; Divide by 2 to get actual index (0-9)
    
    ; Select color based on star index
    mov bx, star_colors
    add bx, ax        ; Get color for this star
    mov bl, [bx]      ; Load color attribute
    
    ; Draw star with color
    mov al, '.'       ; Star character
    call print_color_char
    
    pop si
    add si, 2
    pop cx
    loop ds_loop
    ret

; ========== DRAW FUNCTIONS ==========
draw_all:
    ; Title
    mov dh, 5
    mov dl, 35
    call set_cur
    mov si, txt_title
    mov bl, 0Eh
    call print_color
    
    ; Line
    mov dh, 6
    mov dl, 34
    call set_cur
    mov si, txt_line
    mov bl, 0Eh
    call print_color
    
    ; Menu
    call draw_menu
    
    ; Controls
    mov dh, 22
    mov dl, 22
    call set_cur
    mov si, txt_controls
    mov bl, 0Eh
    call print_color
    
    ; Stars
    call draw_stars
    ret

draw_menu:
    ; Clear area
    mov cx, 4
    mov dh, 10
clear_m:
    push cx
    mov dl, 34
    call set_cur
    mov cx, 12
clear_l:
    mov ah, 09h
    mov al, ' '
    mov bh, 0
    mov bl, 0E0h
    int 10h
    inc dl
    push dx
    call set_cur
    pop dx
    loop clear_l
    pop cx
    add dh, 2
    loop clear_m
    
    ; Items
    mov dh, 10
    mov dl, 35
    call set_cur
    mov si, menu1
    mov al, 0
    call draw_item
    
    mov dh, 12
    mov dl, 35
    call set_cur
    mov si, menu2
    mov al, 1
    call draw_item
    
    mov dh, 14
    mov dl, 35
    call set_cur
    mov si, menu3
    mov al, 2
    call draw_item
    
    mov dh, 16
    mov dl, 35
    call set_cur
    mov si, menu4
    mov al, 3
    call draw_item
    ret

draw_item:
    cmp al, [select]
    je draw_sel
    
    ; Normal
    push si
    mov si, txt_space
    mov bl, 0E0h
    call print_color
    pop si
    mov bl, 0E0h
    call print_color
    ret

draw_sel:
    ; Selected
    push si
    mov si, txt_arrow
    mov bl, 0C0h
    call print_color
    pop si
    mov bl, 0E0h
    call print_color
    ret

; ========== DATA ==========
txt_title:    db 'JellyFish Clash', 0
txt_line:     db '=============', 0
menu1:        db 'Start Game', 0
menu2:        db 'Instructions', 0
menu3:        db 'Settings', 0
menu4:        db 'Exit', 0
txt_arrow:    db '> ', 0
txt_space:    db '  ', 0
txt_controls: db 'Up/Down:Move  Enter:Select  ESC:Exit  S:Toggle Sound', 0
txt_anim_title: db 'Starting', 0
txt_anim_instructions: db 'Press any key to return to menu', 0

; Tutorial data
tutorial_title: db 'TUTORIAL - Learn to Play!', 0
tutorial_border_top:    db 0C9h
times 78 db 0CDh
db 0BBh, 0
tutorial_border_side:   db 0BAh, 0
tutorial_border_bottom: db 0C8h
times 78 db 0CDh
db 0BCh, 0

tutorial_welcome_msg: db 'Welcome to JellyFish Clash Tutorial! Press any key to start...', 0
tutorial_move_msg: db 'STEP 1: Use ARROW KEYS to move your jelly character around.', 0
tutorial_collect_msg: db 'STEP 2: Collect all YELLOW STARS (*) to earn points!', 0
tutorial_avoid_msg: db 'STEP 3: Avoid the RED OBSTACLES! Collect BLUE/GREEN power-ups.', 0
tutorial_complete_msg: db 'Tutorial Complete! Press ESC or ENTER to return to menu.', 0

tutorial_score_text: db 'Score:', 0
tutorial_step_text: db 'Step:', 0
tutorial_controls: db 'Arrow Keys: Move  ESC/Enter: Exit Tutorial', 0

; Borders
border_top:    db 0C9h
times 78 db 0CDh
db 0BBh, 0
border_side:   db 0BAh, 0
border_bottom: db 0C8h
times 78 db 0CDh
db 0BCh, 0

; Settings borders
settings_top:    db 0DAh
times 29 db 0C4h
db 0BFh, 0
settings_side:   db 0B3h, 0
settings_bottom: db 0C0h
times 29 db 0C4h
db 0D9h, 0

; Instructions
instr_title:    db '=== INSTRUCTIONS ===', 0
instr_controls: db 'Up/Down:Scroll  Enter/ESC:Back  S:Toggle Sound', 0
scroll_indicator: db '[SCROLL]', 0

; Settings
settings_title: db 'SETTINGS', 0
txt_sound:      db 'Sound: ', 0
txt_on:         db 'ON', 0
txt_off:        db 'OFF', 0
settings_controls: db 'S:Toggle Sound  Enter/ESC:Back', 0

; Detailed instructions text (with newlines)
instructions_text:
    db '=== JELLYFISH CLASH - INSTRUCTIONS ===', 13, 10
    db '', 13, 10
    db 'Welcome to JellyFish Clash!', 13, 10
    db '', 13, 10
    db 'GAME OBJECTIVE:', 13, 10
    db 'Control your jelly character and collect', 13, 10
    db 'as many stars as possible while avoiding', 13, 10
    db 'obstacles.', 13, 10
    db '', 13, 10
    db 'BASIC CONTROLS:', 13, 10
    db 'Arrow Keys - Move your character', 13, 10
    db 'Space Bar  - Jump/Action', 13, 10
    db 'ESC        - Exit to menu', 13, 10
    db 'P          - Pause game', 13, 10
    db '', 13, 10
    db 'GAMEPLAY:', 13, 10
    db '1. Collect stars to increase score', 13, 10
    db '2. Avoid red obstacles', 13, 10
    db '3. Special power-ups appear randomly', 13, 10
    db '4. Complete levels to progress', 13, 10
    db '', 13, 10
    db 'POWER-UPS:', 13, 10
    db '* Speed Boost - Move faster (Blue)', 13, 10
    db '* Shield      - Temporary protection (Green)', 13, 10
    db '* Multiplier  - Double points (Yellow)', 13, 10
    db '* Time Freeze - Stop obstacles (Cyan)', 13, 10
    db '', 13, 10
    db 'SCORING:', 13, 10
    db 'Normal Star: 10 points', 13, 10
    db 'Golden Star: 50 points', 13, 10
    db 'Power-up: 25 points', 13, 10
    db 'Level completion: 100 points', 13, 10
    db '', 13, 10
    db 'DIFFICULTY LEVELS:', 13, 10
    db 'Easy   - Slow moving obstacles', 13, 10
    db 'Medium - Moderate speed', 13, 10
    db 'Hard   - Fast obstacles, more enemies', 13, 10
    db '', 13, 10
    db 'TIPS:', 13, 10
    db '1. Plan your route before moving', 13, 10
    db '2. Save power-ups for difficult sections', 13, 10
    db '3. Watch for patterns in obstacle movement', 13, 10
    db '4. Practice makes perfect!', 13, 10
    db '', 13, 10
    db 'SETTINGS:', 13, 10
    db 'Press S anytime to toggle sound', 13, 10
    db 'Adjust settings from main menu', 13, 10
    db '', 13, 10
    db 'Have fun playing Jellyfish Clash!', 13, 10
    db '', 13, 10
    db 'Credits:', 13, 10
    db 'Programmed in Assembly x86', 13, 10
    db 'Designed for DOS environment', 13, 10
    db 'Version 1.0', 13, 10
    db 0  ; End of text

; Color attributes for stars (10 different colors)
star_colors:
    db 0Eh  ; Yellow on black
    db 0Ah  ; Light green on black
    db 0Bh  ; Light cyan on black
    db 0Ch  ; Light red on black
    db 0Dh  ; Light magenta on black
    db 09h  ; Light blue on black
    db 0Fh  ; White on black
    db 08h  ; Gray on black (dark)
    db 02h  ; Green on black
    db 03h  ; Cyan on black

; Variables
select:         db 0
random:         dw 1234
left_pos:       dw 0
right_pos:      dw 79
sound_enabled:  db 1      ; 1 = enabled, 0 = disabled
scroll_pos:     dw 0

; Tutorial variables
jelly_x:        db 40
jelly_y:        db 12
tutorial_score: dw 0
tutorial_step:  db 0
stars_collected: db 0
tutorial_timer: db 0
tutorial_progress: db 0

; Tutorial objects
star1_x:        db 30
star1_y:        db 10
star1_active:   db 1

star2_x:        db 60
star2_y:        db 14
star2_active:   db 1

star3_x:        db 45
star3_y:        db 8
star3_active:   db 1

obstacle_x:     db 70
obstacle_y:     db 12
obstacle_active: db 0
obstacle_dir:   db 0

powerup_x:      db 10
powerup_y:      db 18
powerup_active: db 0
powerup_type:   db 0

; Stars (X, Y)
stars:
    db 10, 3
    db 25, 8
    db 40, 2
    db 55, 15
    db 70, 4
    db 15, 20
    db 30, 12
    db 65, 7
    db 45, 18
    db 20, 23