[org 0x0100]        
    mov ax, 0C5A3h  
    xor bx, bx       

repeat:
    cmp ax, 1
    je done          

    xor cx, cx      
    mov dx, ax       
    mov si, 16       

counter:
    test dx, 1       
    jz no_one
    inc cx          

no_one:
    shr dx, 1     
    dec si
    jnz counter   

    mov ax, cx       
    inc bx          
    jmp repeat      

done:
    mov ax, 0x4C00   
    int 0x21
