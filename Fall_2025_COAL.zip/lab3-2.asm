[org 0x0100]

mov ax,06
mov bx,0000

mul ax, ax

mov ax,0x4c00
int 0x21


