[org 0x0100]
jmp start
x : dw 2
y : dw 3

multiply: 
    push bp
    mov bp,sp
    sub sp,2
    mov word[bp-2],0

    mov ax,[bp+4] 
    mov cx,[bp+6]  
    mov dx,16
    
checkbit: 
    shr cx,1
    jnc skip
    add [bp-2],ax

skip:
    shl ax,1
    dec dx
    jnz checkbit

    mov ax,[bp-2]
    mov sp,bp
    pop bp
    ret 4          ; Clean up 2 parameters (4 bytes)

power:
    push bp
    mov bp,sp
    push bx   ; save value of y
    push cx   ; save cx
    push dx   ; save dx (might be modified by multiply)

    mov ax,[bp+4]   ; x value
    mov bx,[bp+6]   ; y value 

    cmp bx,0  
    jz zerocase 

    cmp bx,1  
    jz onecase

    mov cx,ax       ; cx = result = x
    dec bx          ; bx = remaining multiplications

power_1:
    cmp bx,0
    jz done

    push cx
    push word[bp+4] ; push x
    call multiply   ; ax = cx * x
    
    mov cx,ax       ; update result
    dec bx
    jmp power_1

zerocase:
    mov ax,1
    jmp done_exit

onecase:
    mov ax,[bp+4]   ; return x^1 = x
    jmp done_exit

done:
    mov ax,cx       ; return result from cx

done_exit:
    pop dx
    pop cx
    pop bx
    pop bp
    ret 4           ; Clean up 2 parameters (4 bytes)

start:
    mov si, x       ; SI = address of x
    mov ax, [si]    ; AX = value at x
    mov si, y       ; SI = address of y  
    mov bx, [si]    ; BX = value at y
    
    push bx         ; push y (exponent)
    push ax         ; push x (base)
    
    call power      ; AX = x^y
    
    ; AX now contains the result
    ; For x=2, y=3: AX should be 8
    
    mov ax,0x4c00
    int 0x21