[org 0x0100]
jmp start

n: dw 5         ; number for factorial

multiply:
push bp
mov bp,sp
sub sp,2
mov word [bp-2],0     ; local result = 0

mov ax,[bp+4]         ; multiplicand
mov cx,[bp+6]         ; multiplier
mov dx,16             ; 16 bits

checkbit:
shr cx,1              ; shift multiplier right
jnc skip
add [bp-2],ax         ; if bit = 1, add multiplicand

skip:
shl ax,1              ; shift multiplicand left
dec dx
jnz checkbit

mov ax,[bp-2]         ; final result in ax
mov sp,bp
pop bp
ret 4                 ; remove both parameters

factorial:
push bp
mov bp,sp

mov ax,[bp+4]         ; number (n)
cmp ax,1
jbe base_case         ; if n <= 1 → return 1

; recursive case: n * factorial(n-1)
dec ax
push ax               ; push (n-1)
call factorial        ; get factorial(n-1)
pop bx                ; result in BX (returned value from stack)
push bx               ; multiplier = factorial(n-1)
push word [bp+4]      ; multiplicand = n
call multiply
; result in AX

; return result on stack
push ax
jmp done

base_case:
mov ax,1
push ax               ; return 1 on stack

done:
mov sp,bp
pop bp
ret 2                 ; remove parameter n

start:
mov ax,[n]
push ax
call factorial

pop ax                 ; factorial result in AX

mov ax,0x4c00
int 0x21

