[org 0x0100]


    Num1 dw 0x4880, 0x9539, 0x4880, 0x9539
    Num2 dw 0x5A08, 0xB97B, 0x5A08, 0xB97B
    Result dw 0,0,0,0

section .text
start:
    mov ax, [Num1]
    add ax, [Num2]
    mov [Result], ax

    mov ax, [Num1+2]
    adc ax, [Num2+2]
    mov [Result+2], ax

    mov ax, [Num1+4]
    adc ax, [Num2+4]
    mov [Result+4], ax

    mov ax, [Num1+6]
    adc ax, [Num2+6]
    mov [Result+6], ax

    mov ax, 4C00h
    int 21h