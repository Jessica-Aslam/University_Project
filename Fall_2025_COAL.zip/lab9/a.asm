[org 0x0100]
jmp start

data: db "i am a coal student", 0

start:
    mov bx, 0
    mov al, 'a'
    mov di, data

loop_start:
    cmp byte [di], 0
    je done
    cmp byte [di], al
    jne skip
    inc bx
skip:
    inc di
    jmp loop_start

done:
    ; bx contains the frequency of 'a'
    mov ax, 0x4c00
    int 0x21