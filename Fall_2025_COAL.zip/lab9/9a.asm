[org 0x0100]
jmp start

sleep:
         push cx
         push ax
         push di
         mov cx,0xffff
delay:   loop delay
         mov ax,0x0720
         mov word[es:di],ax
         mov word[es:si],ax
         pop di
         pop ax
         pop cx
         ret
clrscr:   
              push es             
              push ax 
              push cx 
              push di 
              mov  ax, 0xb800 
              mov  es, ax             ; point es to video base 
              xor  di, di             ; point di to top left column 
              mov  ax, 0x0720         ; space char in normal attribute 
              mov  cx, 2000           ; number of screen locations 
              cld                     ; auto increment mode 
              rep  stosw              ; clear the whole screen 
              pop  di  
              pop  cx 
              pop  ax 
              pop  es 
              ret 
  
asterik_forward:
            push ax
	    push es
	    push cx
            push di
    print_forward:
            mov ax,0xb800
            mov es,ax

            mov al,80
            mov bl,13
            mul bl    ; row number 
            add ax,1       ; column number
            shl ax,1
            mov di,ax
            mov cx,40
            mov ax,0x072A   

            mov al,80
            mov bl,13
            mul bl      ; row number 
            add ax,79       ; column number
            shl ax,1
            mov si,ax
            mov cx,40
            mov ax,0x072A   
print_age: 
     mov word[es:di],ax
     mov word[es:si],ax
     call sleep
     call sleep
     call sleep
     add di,2
     sub si,2
     loop print_age

     pop di
     pop cx
     pop es
     pop ax
     ret

asterik_backward:
            push ax
	    push es
	    push cx
            push di
    print_backwardd:
            mov ax,0xb800
            mov es,ax

            mov al,80
            mov bl,13
            mul bl    ; row number 
            add ax,40       ; column number
            shl ax,1
            mov di,ax
            mov cx,40
            mov ax,0x072A   

            mov al,80
            mov bl,13
            mul bl      ; row number 
            add ax,40       ; column number
            shl ax,1
            mov si,ax
            mov cx,40
            mov ax,0x072A   
print_peeche: 
     mov word[es:di],ax
     mov word[es:si],ax
     call sleep
     call sleep
     call sleep
     sub di,2
     add si,2
     loop print_peeche

     pop di
     pop cx
     pop es
     pop ax
     ret

start:        call clrscr             ; call clrscr subroutine 
         asterik:
              call asterik_forward
              call asterik_backward
              jmp asterik
              mov  ax, 0x4c00         ; terminate program 
              int  0x21 
