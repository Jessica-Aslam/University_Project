[org 0x010]
jmp start

sleep:
    push cx
    push dx
    mov cx, 0xFFFF
d1: mov dx, 0xFFFF
d2: dec dx
    jnz d2
    dec cx
    jnz d1
    pop dx
    pop cx
    ret

clrscr:   
              push es             
              push ax 
              push cx 
              push di 
              mov  ax, 0xb800 
              mov  es, ax             ; point es to video base 
              xor  di, di             ; point di to top left column 
              mov  ax, 0x0720         ; space char in normal attribute 
              mov  cx, 2000           ; number of screen locations 
              cld                     ; auto increment mode 
              rep  stosw              ; clear the whole screen 
              pop  di  
              pop  cx 
              pop  ax 
              pop  es 
              ret 

scrollup:     push bp 
              mov  bp,sp 
              push ax 
              push cx 
              push si   
              push di 
              push es 
              push ds 
 
              mov  ax, 80             ; load chars per row in ax 
              mul  byte [bp+4]        ; calculate source position 
              mov  si, ax             ; load source position in si 
              push si                 ; save position for later use 
              shl  si, 1              ; convert to byte offset 
              mov  cx, 2000           ; number of screen locations 
              sub  cx, ax             ; count of words to move 
              mov  ax, 0xb800 
              mov  es, ax             ; point es to video base 
              mov  ds, ax             ; point ds to video base 
              xor  di, di             ; point di to top left column 
              cld                     ; set auto increment mode 
              rep  movsw              ; scroll up 

              mov  ax, 0x0720         ; space in normal attribute 
              pop  cx                 ; count of positions to clear 
              rep  stosw              ; clear the scrolled space 
 
              pop  ds 
              pop  es 
              pop  di 
              pop  si 
              pop  cx 
              pop  ax 
              pop  bp 
              ret  2 

scrolldown:   push bp 
              mov  bp,sp 
              push ax 
              push cx 
              push si   
              push di 
              push es 
              push ds 
 
              mov  ax, 80             ; load chars per row in ax 
              mul  byte [bp+4]        ; calculate source position 
              push ax                 ; save position for later use 
              shl  ax, 1              ; convert to byte offset 
              mov  si, 3998           ; last location on the screen 
              sub  si, ax             ; load source position in si 
              mov  cx, 2000           ; number of screen locations 
              sub  cx, ax             ; count of words to move 
              mov  ax, 0xb800 
              mov  es, ax             ; point es to video base 
              mov  ds, ax             ; point ds to video base 
              mov  di, 3998           ; point di to lower right column 
              std                     ; set auto decrement mode 
              rep  movsw              ; scroll up 

              mov  ax, 0x0720         ; space in normal attribute 
              pop  cx                 ; count of positions to clear 
              rep  stosw              ; clear the scrolled space 
 
              pop  ds 
              pop  es 
              pop  di 
              pop  si 
              pop  cx 
              pop  ax 
              pop  bp 
              ret  2 
 
start:        
	infinite:      
	      mov  ax,3
              push ax                 ; push number of lines to scroll 
              call scrolldown         ; call scroll down subroutine 
              call sleep

              mov  ax,3 
              push ax                 ; push number of lines to scroll 
              call scrollup           ; call the scroll up subroutine 
              call sleep

              jmp infinite
              mov  ax, 0x4c00         ; terminate program 
              int  0x21 