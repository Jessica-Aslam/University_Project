#include <iostream>
#include <string>
#include<fstream>
using namespace std;

//person class (Abstract base class)
class Person 
{
	protected:
    	string name;
    	string cnic;

	public:
    	Person() 
		{
			name=" ";
			cnic=" ";				
		} 
    	Person(string n, string c)
		{
			name=n;
			cnic=c;	
		}
		
    	virtual void displayInfo() const = 0;
    	
    	string getName() const
		{
			return name; 
		}
		
    	string getCNIC() const 
		{ 
			return cnic; 
		}
    	virtual ~Person() {}
};

//student inherited from Person
class Student : public Person 
{
	private:
    	string id;
    	float marks;
    	string degree;

	public:
    	Student() : Person()
		{
			id=" ";
			marks=0.0;
			degree=" ";
		}
		
    	Student(string n, string c, string i, float m, string d) : Person(n, c)
		{
			id=i;
			marks=m;
			degree=d;
		}
		
    	void displayInfo() const override 
		{
    	    cout<< "Name: " << name;
			cout<< ", CNIC: " << cnic;
			cout<< ", ID: " << id;
			cout<< ", Marks: " << marks;
			cout<< ", Degree: " << degree << endl;
    	}
    	string getID() const 
		{ 
			return id; 
		}
    	
		float getMarks() const 
		{
		return marks; 
		}
    	
		string getDegree() const 
		{ 
			return degree; 
		}
    	
		bool operator==(const Student& other) const //Operator overloading == 
		{ 
			return id == other.id && cnic == other.cnic; 
		}
    	friend ostream& operator<<(ostream& out, const Student& s) //<< operator Overloading 
		{
    		out << s.name << "," << s.cnic << "," << s.id << "," << s.marks << "," << s.degree;
       		return out;
    	}
};

//Subject class
class Subject 
{
	private:
    	string subjectName;
    	int creditHours;

	public:
    	Subject()
		{
			subjectName=" ";
			creditHours=0;
		}
		
    	Subject(string n, int h) 
		{
			subjectName=n;
			creditHours=h;	
		} 
    	void display() const 
		{
    	    cout << "Subject: " << subjectName << ", Credit Hours: " << creditHours << endl;
    	}
    	string getName() const 
		{ 
			return subjectName; 
		}
		
    	friend Subject operator+(const Subject& a, const Subject& b) //overloading + operator
		{
        	return Subject(a.subjectName + "&" + b.subjectName, a.creditHours + b.creditHours);
    	}
};

//Degree class with Subject class Object
class Degree 
{
	private:
    	string degreeName;
    	Subject subjects[4];
    	int subjectCount;

	public:
    	Degree() 
		{
			degreeName=" ";
			subjectCount=0;
		}
		
    	Degree(string n) 
		{
			degreeName=n;
			subjectCount=0;
		} 
		
    	void addSubject(const Subject& s) 
		{
    	    if (subjectCount < 4) 
			{
				subjects[subjectCount++] = s;	
			}
    	}
    	void displayInfo() const 
		{
    	    cout << "Degree Program: " << degreeName << endl;
    	    for (int i = 0; i < subjectCount; i++) 
			{
				subjects[i].display();	
			}
    	}
    	string getName() const 
		{ 
			return degreeName; 
		}
    	
		friend ostream& operator<<(ostream& out, const Degree& d)  //friend function operator << 
		{
    	    out << "Degree: " << d.degreeName;
    	    return out;
    	}
};


//AdmissionRecord class inherited from student which is inherited from person
class AdmissionRecord : public Student 
{
	private:
    	string admissionDate;

	public:
    	AdmissionRecord() : Student()
		{
			admissionDate="N/A";	
		}  
		
    	AdmissionRecord(string n, string c, string i, float m, string d, string date) : Student(n, c, i, m, d)
		{
			admissionDate=date;
		}
    	
		void displayInfo() const override 
		{
    	    Student::displayInfo();
        	cout << "Admission Date: " << admissionDate << endl;
		}
};

//Admin class inherited from person class 
class Admin : public Person  
{
	public:
    	Admin() : Person("admin", "admin-cnic") {}
    	
		void login(string u, string pw) 
		{
    	    if (u == "admin" && pw == "1234") 
			{
				cout << "Thank you for login.\n";	
			}
    	    else 
			{
				cout << "Failed to Login.\nError Admin not Found.\n";	
			}
    	}
    	void displayInfo() const override 
		{
        	cout << "Admin: " << name << endl;
    	}
};

class MeritList : public Student, public Degree 
{
	public:
    	MeritList(Student s, Degree d) : Student(s), Degree(d) {}
    	void displayMeritInfo() const 
		{
    	    cout << "--- Merit Student ---\n";
    	    Student::displayInfo();
    	    Degree::displayInfo();
    	}
};

//college which has student, degree class objects
class College 
{
	private:
    	Student students[100];
    	int studentCount;
    	Degree degrees[5];
    	int degreeCount;

	public:
    	static int totalAdmissions;
    	College() : studentCount(0), degreeCount(0) 
		{ 
			initializeDegrees(); 
		}

	    void initializeDegrees();
	    void registerStudent();
	    void viewAllStudents();
	    void viewDegrees();
	    void searchStudentMenu();
	    void generateMeritList();
	    void saveToFile();
	    void loadFromFile();
};

int College::totalAdmissions = 0;
College college;
Admin admin;

void College::initializeDegrees() 
{
    degrees[0] =Degree("Computer Science");
    degrees[0].addSubject(Subject("ICT", 3));
    degrees[0].addSubject(Subject("PF", 3));
    degrees[0].addSubject(Subject("OOP", 3));
    degrees[0].addSubject(Subject("DLD", 3));

    degrees[1] = Degree("English");
    degrees[1].addSubject(Subject("Literature", 3));
    degrees[1].addSubject(Subject("Grammar", 2));
    degrees[1].addSubject(Subject("Composition", 3));
    degrees[1].addSubject(Subject("Linguistics", 3));

    degrees[2] = Degree("BBA");
    degrees[2].addSubject(Subject("Accounting", 3));
    degrees[2].addSubject(Subject("Marketing", 3));
    degrees[2].addSubject(Subject("Finance", 3));
    degrees[2].addSubject(Subject("HRM", 3));

    degrees[3] = Degree("Biotechnology");
    degrees[3].addSubject(Subject("Genetics", 3));
    degrees[3].addSubject(Subject("Microbiology", 3));
    degrees[3].addSubject(Subject("Cell Biology", 3));
    degrees[3].addSubject(Subject("Biochemistry", 3));

    degrees[4] = Degree("Physics");
    degrees[4].addSubject(Subject("Mechanics", 3));
    degrees[4].addSubject(Subject("Thermodynamics", 3));
    degrees[4].addSubject(Subject("Optics", 3));
    degrees[4].addSubject(Subject("Electromagnetism", 3));

    degreeCount = 5;
}

void College::registerStudent() 
{
    string name, cnic, id, degreeName, date;
    float marks;

    cout << "Enter Name: ";
    cin.ignore();
    getline(cin, name);
    cout << "Enter CNIC: ";
    getline(cin, cnic);
    cout << "Enter ID: ";
    getline(cin, id);
    cout << "Enter Marks: ";
    cin >> marks;
    cin.ignore();
    cout << "Select Degree Program:\n";
    for (int i = 0; i < degreeCount; i++)
        cout << i + 1 << ". " << degrees[i].getName() << endl;

    int choice;
    cin >> choice;
    cin.ignore();
    if (choice < 1 || choice > degreeCount) 
	{
        cout << "Invalid degree choice!\n";
        return;
    }
    degreeName = degrees[choice - 1].getName();
    cout << "Enter Admission Date (DD/MM/YYYY): ";
    getline(cin, date);
    AdmissionRecord newStudent(name, cnic, id, marks, degreeName, date);

    for (int i = 0; i < studentCount; i++) 
	{
        if (students[i] == newStudent) 
		{
            cout << "Student already exists. Registration cancelled.\n";
            return;
        }
    }
    students[studentCount++] = newStudent;
    totalAdmissions++;
    cout << "Student registered successfully!\n";
}

void College::viewAllStudents() 
{
    if (studentCount == 0) 
	{
        cout << "No students registered.\n";
        return;
    }
    for (int i = 0; i < studentCount; i++) students[i].displayInfo();
}

void College::viewDegrees() 
{
    for (int i = 0; i < degreeCount; i++) degrees[i].displayInfo();
}

void College::searchStudentMenu() 
{
    string cnic;
    cout << "Enter CNIC to search: ";
    cin >> cnic;
    for (int i = 0; i < studentCount; i++) 
	{
        if (students[i].getCNIC() == cnic) 
		{
            students[i].displayInfo();
            return;
        }
    }
    cout << "Student not found.\n";
}

void College::generateMeritList() {
    cout << "\n--- Merit List (80+ marks) ---\n";
    bool found = false;
    for (int i = 0; i < studentCount; i++) 
	{
        if (students[i].getMarks() >= 80) 
		{
            Degree matchedDegree;
            for (int j = 0; j < degreeCount; j++) 
			{
                if (degrees[j].getName() == students[i].getDegree()) 
				{
                    matchedDegree = degrees[j];
                    break;
                }
            }
            MeritList ml(students[i], matchedDegree);
            ml.displayMeritInfo();
            cout << "--------------------------\n";
            found = true;
        }
    }
    if (!found) cout << "No students qualified for merit list.\n";
}

void College::saveToFile() 
{
    ofstream out("students.txt");
    for (int i = 0; i < studentCount; i++) out << students[i] << endl;
    out.close();
    cout << "Data saved to students.txt\n";
}

void College::loadFromFile() 
{
    ifstream in("students.txt");
    string name, cnic, id, degree;
    float marks;
    studentCount = 0;
    while (getline(in, name, ',') && getline(in, cnic, ',') && getline(in, id, ',') && (in >> marks) && in.ignore() && getline(in, degree)) 
	{
        students[studentCount++] = Student(name, cnic, id, marks, degree);
    }
    in.close();
    cout << "Data loaded from file.\n";
}

void showMenu() 
{
    cout << "\n===== College Admission Menu =====\n";
    cout<<"      \n";
    cout << "1. Register New Student\n";
    cout << "2. View All Students\n";
    cout << "3. View Degree Programs\n";
    cout << "4. Search Student by CNIC\n";
    cout << "5. Generate Merit List\n";
    cout << "6. Save Records to File\n";
    cout << "7. Load Records from File\n";
    cout << "0. Exit\n";
    cout << "==================================\n";
    cout << "Enter choice: ";
}

int main() 
{
    int choice;
    string user, password;

    cout << "\tWelcome TO Our Website\n";
    //cout << "....Please Login into your Account to See Main Menu....\n";
    cout << "-----Admin Login-----\nUsername: ";
    cin >> user;
    cout << "Password: ";
    cin >> password;
    admin.login(user, password);
	
    do 
	{
        showMenu();
        cin >> choice;
        switch (choice) 
		{
            case 1: college.registerStudent(); break;
            case 2: college.viewAllStudents(); break;
            case 3: college.viewDegrees(); break;
            case 4: college.searchStudentMenu(); break;
            case 5: college.generateMeritList(); break;
            case 6: college.saveToFile(); break;
            case 7: college.loadFromFile(); break;
            case 0: cout << "Exiting...\n"; break;
            default: cout << "Invalid choice.\n";
        }
    } while (choice != 0);

    return 0;
}

