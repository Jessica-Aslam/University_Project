#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;


class Stack {
    char arr[100];
    int top;
public:
    Stack()
    {
        top = -1;
    }
    void push(char c)
    {
        arr[++top] = c; 
    }
    char pop() 
    { 
        return arr[top--];
    }

    char peek() 
    {
        return arr[top]; 
    }

    bool isEmpty() 
    {
        return top == -1; 
    }
};

// Function to check precedence
int precedence(char op) {
    if (op == '^') return 3;
    if (op == '*' || op == '/') return 2;
    if (op == '+' || op == '-') return 1;
    return 0;
}

// Function to reverse a string
void reverseStr(string& s) {
    int n = s.length();
    for (int i = 0; i < n / 2; i++)
        swap(s[i], s[n - i - 1]);
}

// Infix to Postfix conversion
string infixToPostfix(string infix) {
    Stack st;
    string postfix = "";

    for (int i = 0; i < infix.length(); i++) {
        char ch = infix[i];

        // If operand ? add to output
        if (isalnum(ch)) {
            postfix += ch;
        }
        // If '(' ? push to stack
        else if (ch == '(') {
            st.push(ch);
        }
        // If ')' ? pop until '('
        else if (ch == ')') {
            while (!st.isEmpty() && st.peek() != '(')
                postfix += st.pop();
            st.pop(); // Remove '('
        }
        // If operator ? precedence rules
        else {
            while (!st.isEmpty() && precedence(st.peek()) >= precedence(ch)) {
                postfix += st.pop();
            }
            st.push(ch);
        }
    }

    // Pop remaining operators
    while (!st.isEmpty())
        postfix += st.pop();

    return postfix;
}

// Infix to Prefix conversion
string infixToPrefix(string infix) {
    // Step 1: Reverse infix
    reverseStr(infix);

    // Step 2: Swap brackets
    for (int i = 0; i < infix.length(); i++) {
        if (infix[i] == '(') infix[i] = ')';
        else if (infix[i] == ')') infix[i] = '(';
    }

    // Step 3: Get postfix of modified expression
    string postfix = infixToPostfix(infix);

    // Step 4: Reverse postfix to get prefix
    reverseStr(postfix);
    return postfix;
}

int main() {
    string infix;
    cout << "Enter Infix Expression: ";
    cin >> infix;

    string postfix = infixToPostfix(infix);
    string prefix = infixToPrefix(infix);

    cout << "Postfix: " << postfix << endl;
    cout << "Prefix: " << prefix << endl;

    return 0;
}