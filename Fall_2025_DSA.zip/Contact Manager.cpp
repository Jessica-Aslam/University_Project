#include<iostream>
#include<fstream>
#include<string>
#include<algorithm>
using namespace std;
// validation for user input
// validation for using only alphabets
bool isValidName(const string& n)
 {
    if (n.empty()) return false;
    for (char c: n)
     {
        if (!isalpha(c) && c!=' ')
            return false;
    }
    return true;
}
//validation for using only 11 digits
bool isValidPhone(const string& p) 
{
    if (p.length()!=11) return false;
    for (char c: p) 
    {
        if (!isdigit(c))
            return false;
    }
    return true;
}
// validation for making sure that the address is not empty
bool isValidAddress(const string& a) 
{
    return !a.empty();
}

// Converting a string to lowercase
string toLowerCase(const string& s)
 {
    string temp=s;
    transform(temp.begin(), temp.end(), temp.begin(), ::tolower);
    return temp;
}

//doing formatting, first letter uppercase, rest lowercase
string formatName(const string& s) 
{
    if (s.empty()) 
    return s;
    string temp = toLowerCase(s);
    temp[0] = toupper(temp[0]);
    return temp;
}
//Class of Itemtype
class ItemType
 {
    string name;
    string phone;
    string address;

public:
//default constructor
    ItemType() 
    {
        name="unknown";
        phone="unknown";
        address="unknown";
    }
    //parameterized function
    ItemType(string na, string ph, string ad)
    {
    	name=na;
    	phone=ph;
    	address= ad;
    }
//setter for new contact
   void setContact(string na, string ph, string ad)
     {
        if(isValidName(na)) 
        name = formatName(na);
        else 
        cout<<"Invalid name. Only alphabets allowed.\n";

        if(isValidPhone(ph))
         phone = ph;
        else cout<<"Invalid phone. Must be 11 digits.\n";

        if(isValidAddress(ad))
         address= ad;
        else cout<<"Address cannot be empty.\n";
    }
//getter function for variables
    string getName() const 
    { return name; 
    }
    string getPhone() const
     { return phone;
      }
    string getAddress() const 
    { return address;
     }
//display funtion to display contact list
    void displayContact() const {
        cout<<"Name: "<< name
            <<"\nPhone: "<<phone
            <<"\nAddress: "<<address<<"\n\n";
    }
// function for comparision, less than, greater than, and equal too
    bool operator<(const ItemType& obj)const 
    { 
        return toLowerCase(name) < toLowerCase(obj.name); 
    }
    bool operator>(const ItemType& obj)const
     { 
        return toLowerCase(name) > toLowerCase(obj.name); 
    }
    bool operator==(const ItemType& obj)const
     { 
        return toLowerCase(name) == toLowerCase(obj.name); 
    }
};
//class for sortedtype
class SortedType {
    //declaration of array and length
    static const int Max_Items=50;
    ItemType Contact[Max_Items];
    int length;
public:
// default constructor
    SortedType() 
    { length=0; 
    }
//function for checking whether the array is full or not
    bool isFull() const
     { return length==Max_Items; 
     }
     //function for checking if there are elements in array or not
    bool isEmpty() const 
    { return length==0; 
    }
//insert function to add new contact
    void insertItem(const ItemType& obj) 
    {
        if (isFull()) 
        {
            cout<< "List is full, cannot insert.\n";
            return;
        }
        int pos=length-1;
        while(pos>=0 && Contact[pos]>obj)
         {
            Contact[pos+1]=Contact[pos];
            pos--;
        }
        Contact[pos+1]=obj;
        length++;
        cout<<"Contact added successfully.\n";
    }
//delete function to delete a contact, will delete the 1st contact incase of duplication
    void deleteItem(const string& name) 
    {
        int pos=-1;
        string target = toLowerCase(name);
        for(int i=0; i<length; i++)
         {
            if (toLowerCase(Contact[i].getName())==target) 
            {
                pos=i;
                break;
            }
        }
        if(pos==-1) 
        {
            cout<<"Contact Not Found.\n";
            return;
        }
        for (int i=pos; i<length-1; i++) 
        {
            Contact[i]= Contact[i+1];
        }
        length--;
        cout<<"Contact deleted successfully.\n";
    }
//retrieve function for searching, will show all the matches found
    void retrieveItem(const string& name) 
    {
    string searchKey = toLowerCase(name);
    bool found = false;

    for(int i=0; i<length; i++) 
    {
        string contactName = toLowerCase(Contact[i].getName());
        if(contactName.find(searchKey) != string::npos) 
        {
            if(!found) 
            {
                cout<<"Matches found:\n";
            }
            Contact[i].displayContact();
            found = true;
        }
    }

    if(!found) 
    {
        cout<<"No contacts found matching \""<<name<<"\".\n";
    }
}
    //display function to print all contacts
    void displayAll()const
     {
        if(isEmpty())
         {
            cout<<"Contact list is empty.\n";
            return;
        }
        cout<<"\n-----Contact List-----\n";
        for (int i=0; i<length; i++)
            Contact[i].displayContact();
    }
    //function for saving contact in a file
    void SaveToFile(const string& filename)const 
    {
        ofstream outfile(filename);
        if(!outfile) 
        {
            cout<<"File could not be opened\n";
            return;
        }
        for(int i=0; i<length; i++)
         {
            outfile<<Contact[i].getName()<<"\n"
                   <<Contact[i].getPhone()<<"\n"
                   <<Contact[i].getAddress()<<"\n";
        }
        outfile.close();
    }
//function for loading conatacts from the file
    void LoadfromFile(const string& filename) 
    {
        ifstream infile(filename);
        if(!infile) 
        {
            cout<<"No saved contacts.\n";
            return;
        }
        string name, phone, address;
        while (getline(infile,name) && getline(infile, phone) && getline(infile, address)) 
        {
            insertItem(ItemType(name, phone, address));
        }
        infile.close();
    }
};
//main interface for user
int main() 
{
    SortedType ContactList;
    const string filename= "Contacts.txt";
    ContactList.LoadfromFile(filename);
//give different choices to user to choose from
    int choice;
    do {
        cout<<"\n----Contact Manager----\n";
        cout<<"1. Add New Contact\n";
        cout<<"2. Delete a Contact\n";
        cout<<"3. Search for a Contact\n";
        cout<<"4. Display All Contacts\n";
        cout<<"5. Exit\n";
        cout<<"Enter choice: ";
        cin>>choice;
        cin.ignore();
//to add new contact plus checking for validations
        if(choice==1) 
        {
            string name, phone, address;

            do 
            {
                cout<<"Enter Your Name: ";
                getline(cin,name);
                if(!isValidName(name))
                    cout<<"Invalid name. Only alphabets & spaces allowed.\n";
            } 
            while(!isValidName(name));

            do 
            {
                cout<<"Enter Your Phone No (11 digits): ";
                getline(cin,phone);
                if(!isValidPhone(phone))
                    cout<<"Invalid phone. Must be 11 digits.\n";
            } 
            while(!isValidPhone(phone));

            do 
            {
                cout<<"Enter Your Address: ";
                getline(cin,address);
                if(!isValidAddress(address))
                    cout<<"Address cannot be empty.\n";
            } 
            while(!isValidAddress(address));

            ItemType newContact;
            newContact.setContact(name, phone, address);
            ContactList.insertItem(newContact);
        }
        //taking a name to delete a contact
        else if(choice==2) {
            string name;
            cout<<"Enter the name of contact to delete: ";
            getline(cin,name);
            ContactList.deleteItem(name);
        }
        //taking a name to search from the contact list
        else if(choice==3)
         {
            string name;
            cout<<"Enter the name of contact to search: ";
            getline(cin,name);
            ContactList.retrieveItem(name);
        }
        //To display contacts
        else if(choice==4)
         {
            ContactList.displayAll();
        }
        //to save the file before existing the program
        else if(choice==5) 
        {
            ContactList.SaveToFile(filename);
            cout<<"Contacts saved. Exiting!\n";
        }
        //for invalid choice
        else 
        {
            cout<<"Invalid Choice\n";
        }
    } 
    while(choice!=5);

    return 0;
}