#include <iostream>
using namespace std;

const int MAX_ITEMS = 5;
enum RelationType { LESS, GREATER, EQUAL };


// ==============================
//         ItemType Class
// ==============================
class ItemType
{
public:
    ItemType() 
	{ value = 0; }

    RelationType ComparedTo(ItemType otherItem) const
    {
        if (value < otherItem.value)
            return LESS;
        else if (value > otherItem.value)
            return GREATER;
        else
            return EQUAL;
    }

    void Initialize(int number) { value = number; }

    int GetValue() const { return value; }

private:
    int value;
};


// ==============================
//       UnsortedType Class
// ==============================
class UnsortedType
{
public:
    UnsortedType()
    {
        length = 0;
        currentPos = -1;
    }

    void MakeEmpty()
    {
        length = 0;
    }

    bool IsFull() const
    {
        return (length == MAX_ITEMS);
    }

    int GetLength() const
    {
        return length;
    }

    void InsertItem(ItemType item)
    {
        if (!IsFull())
        {
            info[length] = item;
            length++;
        }
        else
        {
            cout << "List is full, cannot insert.\n";
        }
    }

    void RetrieveItem(ItemType& item, bool& found)
    {
        int location = 0;
        bool moreToSearch = (location < length);
        found = false;

        while (moreToSearch && !found)
        {
            switch (item.ComparedTo(info[location]))
            {
            case LESS:
            case GREATER:
                location++;
                moreToSearch = (location < length);
                break;

            case EQUAL:
                found = true;
                item = info[location];
                break;
            }
        }
    }

    void DeleteItem(ItemType item)
    {
        int location = 0;
        while (location < length && item.ComparedTo(info[location]) != EQUAL)
            location++;

        if (location < length)  // found
        {
            info[location] = info[length - 1];
            length--;
        }
        else
        {
            cout << "Item not found.\n";
        }
    }

    void ResetList()
    {
        currentPos = -1;
    }

    void GetNextItem(ItemType& item)
    {
        currentPos++;
        item = info[currentPos];
    }

    // ADT-Compliant print function using GetNextItem
    void PrintList()
    {
        ItemType item;
        ResetList();
        for (int i = 0; i < GetLength(); i++)
        {
            GetNextItem(item);
            cout << item.GetValue() << " ";
        }
        cout << endl;
    }

private:
    int length;
    ItemType info[MAX_ITEMS];
    int currentPos;
};


// ==============================
//             Main
// ==============================
int main()
{
    UnsortedType list;
    ItemType item;
    bool found;

    // Insert items
    item.Initialize(10);
    list.InsertItem(item);
    item.Initialize(20);
    list.InsertItem(item);
    item.Initialize(30);
    list.InsertItem(item);

    cout << "List: ";
    list.PrintList();

    // Retrieve item
    item.Initialize(20);
    list.RetrieveItem(item, found);
    if (found)
        cout << "Item found: " << item.GetValue() << endl;
    else
        cout << "Item not found." << endl;

    // Delete item
    item.Initialize(20);
    list.DeleteItem(item);

    cout << "List after deletion: ";
    list.PrintList();

    // Empty list
    list.MakeEmpty();
    cout << "List length after MakeEmpty: " << list.GetLength() << endl;

    // Fill list again to test IsFull
    item.Initialize(10); list.InsertItem(item);
    item.Initialize(20); list.InsertItem(item);
    item.Initialize(30); list.InsertItem(item);
    item.Initialize(40); list.InsertItem(item);
    item.Initialize(50); list.InsertItem(item);

    if (list.IsFull())
        cout << "List is full." << endl;
    else
        cout << "List is not full." << endl;

    cout << "Final List: ";
    list.PrintList();

    return 0;
}

