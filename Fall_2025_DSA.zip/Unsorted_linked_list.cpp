#include <iostream>
#include <string>
#include <new>
using namespace std;

template <class ItemType>
struct NodeType
{
    ItemType info;
    NodeType<ItemType>* next;
};

template <class ItemType>
class UnsortedType
{
private:
    NodeType<ItemType>* listData;
    NodeType<ItemType>* currentPos;
    int length;

public:
    UnsortedType()
    {
        listData = NULL;
        currentPos = NULL;
        length = 0;
    }

    ~UnsortedType()
    {
        MakeEmpty();
    }

    void MakeEmpty()
    {
        NodeType<ItemType>* tempPtr;

        while (listData != NULL)
        {
            tempPtr = listData;
            listData = listData->next;
            delete tempPtr;
        }

        length = 0;
        currentPos = NULL;
    }

    int LengthIs()
    {
        return length;
    }

    void InsertItem(ItemType item)
    {
        NodeType<ItemType>* location = new NodeType<ItemType>;

        location->info = item;
        location->next = listData;
        listData = location;

        length++;
    }

    void RetrieveItem(ItemType& item, bool& found)
    {
        NodeType<ItemType>* location = listData;
        found = false;

        while (location != NULL)
        {
            if (location->info == item)
            {
                found = true;
                item = location->info;
                return;
            }

            location = location->next;
        }
    }

    void DeleteItem(ItemType item)
    {
        if (listData == NULL)
        {
            cout << "List is empty.\n";
            return;
        }

        NodeType<ItemType>* location = listData;
        NodeType<ItemType>* tempLocation;

        if (listData->info == item)
        {
            tempLocation = listData;
            listData = listData->next;
            delete tempLocation;
            length--;
            cout << "Item deleted successfully.\n";
            return;
        }

        while (location->next != NULL && location->next->info != item)
        {
            location = location->next;
        }

        if (location->next == NULL)
        {
            cout << "Item not found.\n";
            return;
        }

        tempLocation = location->next;
        location->next = location->next->next;

        delete tempLocation;
        length--;

        cout << "Item deleted successfully.\n";
    }

    void ResetList()
    {
        currentPos = NULL;
    }

    void GetNextItem(ItemType& item)
    {
        if (currentPos == NULL)
            currentPos = listData;
        else
            currentPos = currentPos->next;

        if (currentPos != NULL)
            item = currentPos->info;
        else
            item = "";
    }

    void DisplayList()
    {
        NodeType<ItemType>* temp = listData;

        if (temp == NULL)
        {
            cout << "List is empty.\n";
            return;
        }

        cout << "List Items: ";

        while (temp != NULL)
        {
            cout << temp->info << " ";
            temp = temp->next;
        }

        cout << endl;
    }
};

int main()
{
    UnsortedType<string> list;

    list.InsertItem("apple");
    list.InsertItem("banana");
    list.InsertItem("orange");

    int choice;

    do
    {
        cout << "\n===== MAIN MENU =====\n";
        cout << "1. Insert Data\n";
        cout << "2. Search Data\n";
        cout << "3. Delete Data\n";
        cout << "4. Reset Traversal\n";
        cout << "5. Get Next Item\n";
        cout << "6. Display List\n";
        cout << "0. Exit\n";
        cout << "Enter Choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            string data;
            cout << "Enter Data: ";
            cin >> data;
            list.InsertItem(data);
            break;
        }

        case 2:
        {
            string data;
            bool found;

            cout << "Enter Data to Search: ";
            cin >> data;

            list.RetrieveItem(data, found);

            if (found)
                cout << "Found\n";
            else
                cout << "Not Found\n";

            break;
        }

        case 3:
        {
            string data;
            cout << "Enter Data to Delete: ";
            cin >> data;

            list.DeleteItem(data);
            break;
        }

        case 4:
        {
            list.ResetList();
            cout << "Traversal Reset.\n";
            break;
        }

        case 5:
        {
            string data;
            list.GetNextItem(data);

            if (data != "")
                cout << "Next Item: " << data << endl;
            else
                cout << "End of list reached.\n";

            break;
        }

        case 6:
        {
            list.DisplayList();
            break;
        }

        case 0:
            cout << "Program Closed.\n";
            break;

        default:
            cout << "Invalid Choice.\n";
        }

    } while (choice != 0);

    return 0;
}
