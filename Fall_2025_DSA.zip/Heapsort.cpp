#include <iostream>
using namespace std;

class ItemType {
private:
    int value;

public:
    ItemType() {
        value = 0;
    }

    void Set(int v) {
        value = v;
    }

    int Get() {
        return value;
    }
    int CompareTo(ItemType other) {
        if (value < other.value) return -1;
        if (value > other.value) return 1;
        return 0;
    }
};
class Heap {
public:
    int heapSize;
    void maxHeapify(ItemType A[], int i) {
        int left = 2 * i;
        int right = 2 * i + 1;
        int largest = i;

        if (left <= heapSize && A[left].Get() > A[largest].Get())
            largest = left;

        if (right <= heapSize && A[right].Get() > A[largest].Get())
            largest = right;

        if (largest != i) {
            // swap
            ItemType temp = A[i];
            A[i] = A[largest];
            A[largest] = temp;

            maxHeapify(A, largest);
        }
    }
    void buildMaxHeap(ItemType A[], int n) {
        heapSize = n;

        for (int i = heapSize / 2; i >= 1; i--) {
            maxHeapify(A, i);
        }
    }

    void heapSort(ItemType A[], int n) {
        buildMaxHeap(A, n);

        for (int i = n; i >= 2; i--) {

            // swap A[1] and A[i]
            ItemType temp = A[1];
            A[1] = A[i];
            A[i] = temp;

            heapSize--;
            maxHeapify(A, 1);
        }
    }
};
int main() {

    Heap H;

    // A[0] ignore, 1-based indexing
    ItemType A[11];

    int raw[11] = { 0, 20, 11, 10, 8, 7, 5, 3, 2, 9, 1 };
    int n = 10;

    for (int i = 1; i <= n; i++) {
        A[i].Set(raw[i]);
    }

    cout << " Array To Sort: ";
    for (int i = 1; i <= n; i++)
        cout << A[i].Get() << " ";
    cout << endl;

    H.heapSort(A, n);

    cout << "Sorted Array:   ";
    for (int i = 1; i <= n; i++)
        cout << A[i].Get() << " ";
    cout << endl;

    return 0;
}
