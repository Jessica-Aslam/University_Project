#include <iostream>
#include <fstream>
using namespace std;

// ====================== ItemType Class ======================
enum RelationType { LESS, GREATER, EQUAL };

class ItemType 
{
public:
    ItemType();
    RelationType ComparedTo(ItemType other) const;
    void Print() const;
    void Initialize(int number);
    int GetValue() const;
private:
    int value;
};

ItemType::ItemType() {
    value = 0;
}

RelationType ItemType::ComparedTo(ItemType other) const {
    if (value < other.value)
        return LESS;
    else if (value > other.value)
        return GREATER;
    else
        return EQUAL;
}

void ItemType::Print() const {
    cout << value << " ";
}

void ItemType::Initialize(int number) {
    value = number;
}

int ItemType::GetValue() const {
    return value;
}

// ====================== SortedType Class ======================
const int MAX_ITEMS = 100;

class SortedType {
public:
    SortedType();
    void MakeEmpty();
    bool IsFull() const;
    int LengthIs() const;
    void RetrieveItem(ItemType& item, bool& found);
    void InsertItem(ItemType item);
    void DeleteItem(ItemType item);
    void ResetList();
    void GetNextItem(ItemType& item);

private:
    int length;
    ItemType info[MAX_ITEMS];
    int currentPos;
};

SortedType::SortedType() {
    length = 0;
    currentPos = -1;
}

void SortedType::MakeEmpty() {
    length = 0;
}

bool SortedType::IsFull() const {
    return (length == MAX_ITEMS);
}

int SortedType::LengthIs() const {
    return length;
}

// Binary search retrieval
void SortedType::RetrieveItem(ItemType& item, bool& found) {
    int first = 0;
    int last = length - 1;
    int mid;
    found = false;

    while (first <= last && !found) {
        mid = (first + last) / 2;
        RelationType relation = item.ComparedTo(info[mid]);
        if (relation == LESS)
            last = mid - 1;
        else if (relation == GREATER)
            first = mid + 1;
        else
            found = true;
    }
}

// Insert in sorted order
void SortedType::InsertItem(ItemType item) {
    if (IsFull()) {
        cout << "List is full. Cannot insert.\n";
        return;
    }

    int location = 0;
    while (location < length && item.ComparedTo(info[location]) == GREATER) {
        location++;
    }

    for (int index = length; index > location; index--) {
        info[index] = info[index - 1];
    }

    info[location] = item;
    length++;
#include <iostream>
#include <fstream>
using namespace std;


enum RelationType { LESS, GREATER, EQUAL };

class ItemType {
public:
    ItemType();
    RelationType ComparedTo(ItemType other) const;
    void Print() const;
    void Initialize(int number);
    int GetValue() const;
private:
    int value;
};

ItemType::ItemType() {
    value = 0;
}

RelationType ItemType::ComparedTo(ItemType other) const {
    if (value < other.value)
        return LESS;
    else if (value > other.value)
        return GREATER;
    else
        return EQUAL;
}

void ItemType::Print() const {
    cout << value << " ";
}

void ItemType::Initialize(int number) {
    value = number;
}

int ItemType::GetValue() const {
    return value;
}


const int MAX_ITEMS = 100;

class SortedType {
public:
    SortedType();
    void MakeEmpty();
    bool IsFull() const;
    int LengthIs() const;
    void RetrieveItem(ItemType& item, bool& found);
    void InsertItem(ItemType item);
    void DeleteItem(ItemType item);
    void ResetList();
    void GetNextItem(ItemType& item);

private:
    int length;
    ItemType info[MAX_ITEMS];
    int currentPos;
};

SortedType::SortedType() {
    length = 0;
    currentPos = -1;
}

void SortedType::MakeEmpty() {
    length = 0;
}

bool SortedType::IsFull() const {
    return (length == MAX_ITEMS);
}

int SortedType::LengthIs() const {
    return length;
}


void SortedType::RetrieveItem(ItemType& item, bool& found) {
    int first = 0;
    int last = length - 1;
    int mid;
    found = false;

    while (first <= last && !found) {
        mid = (first + last) / 2;
        RelationType relation = item.ComparedTo(info[mid]);
        if (relation == LESS)
            last = mid - 1;
        else if (relation == GREATER)
            first = mid + 1;
        else
            found = true;
    }
}


void SortedType::InsertItem(ItemType item) {
    if (IsFull()) {
        cout << "List is full Cannot insert.\n";
        return;
    }

    int location = 0;
    while (location < length && item.ComparedTo(info[location]) == GREATER) {
        location++;
    }

    for (int index = length; index > location; index--) {
        info[index] = info[index - 1];
    }

    info[location] = item;
    length++;
}


void SortedType::DeleteItem(ItemType item) {
    if (length == 0) {
        cout << "List is empty Cannot delete.\n";
        return;
    }

    int location = 0;
    while (location < length && item.ComparedTo(info[location]) != EQUAL) {
        location++;
    }

    if (location == length) {
        cout << "Item not found.\n";
        return;
    }

    for (int index = location + 1; index < length; index++) {
        info[index - 1] = info[index];
    }

    length--;
}

void SortedType::ResetList() {
    currentPos = -1;
}

void SortedType::GetNextItem(ItemType& item) {
    currentPos++;
    item = info[currentPos];
}


int main() {
    SortedType list;
    ItemType item;
    bool found;

    
    ifstream inFile("sorted.txt");
    if (inFile) {
        int num;
        while (inFile >> num) {
            item.Initialize(num);
            list.InsertItem(item);
        }
        inFile.close();
    }

    cout << "Initial List: \n";
    list.ResetList();
    for (int i = 0; i < list.LengthIs(); i++) {
        list.GetNextItem(item);
        item.Print();
    }
    cout << "\n\n";


    cout << "Inserting 50, 10, 30, 70, 20...\n";
    int numsToInsert[] = {50, 10, 30, 70, 20};
    for (int i=0;i<6;i++) 
	{
        item.Initialize(i);
        list.InsertItem(item);
    }

    cout << "List after insertions: ";
    list.ResetList();
    for (int i = 0; i < list.LengthIs(); i++) 
	{
        list.GetNextItem(item);
        item.Print();
    }
    cout << "\n\n";

    cout << "Searching for 30...\n";
    item.Initialize(30);
    list.RetrieveItem(item, found);
    cout << (found ? "Found!" : "Not Found!") << "\n\n";

    cout << "Deleting 50...\n";
    item.Initialize(50);
    list.DeleteItem(item);

    cout << "List after deletion: ";
    list.ResetList();
    for (int i = 0; i < list.LengthIs(); i++) {
        list.GetNextItem(item);
        item.Print();
    }
    cout << "\n\n";

    cout << "Current list length: " << list.LengthIs() << "\n\n";

    
    ofstream outFile("sorted.txt");
    if (outFile) {
        list.ResetList();
        for (int i = 0; i < list.LengthIs(); i++) {
            list.GetNextItem(item);
            outFile << item.GetValue() << endl;
        }
        outFile.close();
    }

    cout << "Final list saved to file.\n";
   

    return 0;
}
// Delete item
void SortedType::DeleteItem(ItemType item) {
    if (length == 0) {
        cout << "List is empty. Cannot delete.\n";
        return;
    }

    int location = 0;
    while (location < length && item.ComparedTo(info[location]) != EQUAL) {
        location++;
    }

    if (location == length) {
        cout << "Item not found.\n";
        return;
    }

    for (int index = location + 1; index < length; index++) {
        info[index - 1] = info[index];
    }

    length--;
}

void SortedType::ResetList() {
    currentPos = -1;
}

void SortedType::GetNextItem(ItemType& item) {
    currentPos++;
    item = info[currentPos];
}

// ====================== Main Function ======================
int main() {
    SortedType list;
    int choice, number;
    bool found;
    ItemType item;

    // === Load from file at start ===
    ifstream inFile("sorted_list.txt");
    if (inFile) {
        while (inFile >> number) {
            item.Initialize(number);
            list.InsertItem(item);
        }
        inFile.close();
    }

    do {
        cout << "\n=== Sorted List ADT Menu ===\n";
        cout << "1. Insert Item\n";
        cout << "2. Delete Item\n";
        cout << "3. Search Item\n";
        cout << "4. Display All Items\n";
        cout << "5. Get Length\n";
        cout << "6. Make Empty\n";
        cout << "7. Save to File\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                cout << "Enter number to insert: ";
                cin >> number;
                item.Initialize(number);
                list.InsertItem(item);
                break;
            }
            case 2: {
                cout << "Enter number to delete: ";
                cin >> number;
                item.Initialize(number);
                list.DeleteItem(item);
                break;
            }
            case 3: {
                cout << "Enter number to search: ";
                cin >> number;
                item.Initialize(number);
                list.RetrieveItem(item, found);
                if (found)
                    cout << "Item found in the list.\n";
                else
                    cout << "Item not found.\n";
                break;
            }
            case 4: {
                cout << "List contents (sorted): ";
                list.ResetList();
                for (int i = 0; i < list.LengthIs(); i++) {
                    list.GetNextItem(item);
                    item.Print();
                }
                cout << "\n";
                break;
            }
            case 5: {
                cout << "Current list length: " << list.LengthIs() << "\n";
                break;
            }
            case 6: {
                list.MakeEmpty();
                cout << "List has been emptied.\n";
                break;
            }
            case 7: {
                ofstream outFile("sorted_list.txt");
                if (!outFile) {
                    cout << "Error opening file for writing.\n";
                } else {
                    list.ResetList();
                    for (int i = 0; i < list.LengthIs(); i++) {
                        list.GetNextItem(item);
                        outFile << item.GetValue() << endl;
                    }
                    outFile.close();
                    cout << "List saved to file successfully.\n";
                }
                break;
            }
            case 0: {
                cout << "Saving and exiting...\n";
                ofstream outFile("sorted_list.txt");
                if (outFile) {
                    list.ResetList();
                    for (int i = 0; i < list.LengthIs(); i++) {
                        list.GetNextItem(item);
                        outFile << item.GetValue() << endl;
                    }
                    outFile.close();
                }
                break;
            }
            default:
                cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 0);

    return 0;
}

